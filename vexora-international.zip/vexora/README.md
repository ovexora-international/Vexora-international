# Vexora International — Setup Guide

Ye poora project 2 hisson mein hai:
1. **backend/Code.gs** → Google Apps Script (database ka kaam Google Sheets karegi)
2. **frontend/** → Sab website pages (HTML/CSS/JS)

---

## STEP 1 — Google Sheet aur Apps Script Banayein

1. [sheets.google.com](https://sheets.google.com) par jaake ek nayi **blank spreadsheet** banayein.
   Naam de dein: `Vexora Database`

2. Sheet ke andar upar menu se: **Extensions → Apps Script** click karein.

3. Jo editor khulega, usmein jo default code hai (`function myFunction(){}`) usay
   **pura delete** karke `backend/Code.gs` ka pura code paste kar dein.

4. Upar **Save** (💾 icon) karein. Project ka naam "Vexora Backend" rakh dein.

5. Ab **Deploy → New deployment** click karein:
   - Gear icon (⚙️) se type select karein: **Web app**
   - Description: `Vexora API v1`
   - Execute as: **Me**
   - Who has access: **Anyone**
   - **Deploy** button dabayein.

6. Google aapse permission maangega — apna account select karke **Allow** kar dein
   (warning aa sakti hai "Google hasn't verified this app", us par **Advanced → Go to Vexora Backend (unsafe)** click karein — ye normal hai kyunke ye aapki khud ki script hai).

7. Deploy hone ke baad ek **Web app URL** milega jo `.../exec` par khatam hota hai.
   **Ye URL copy kar lein** — yehi aapka backend API hai.

8. Pehli baar koi bhi request aane par script khud **8 sheets** bana degi:
   `Users, IPLog, Ads, AdClicks, Transactions, Withdrawals, Shortlinks, Offerwalls`
   (Aap chahen to `frontend/index.html` khol kar ek test login karke check kar sakte hain ke sheets ban gayi hain.)

---

## STEP 1.5 — hCaptcha Setup (Faucet ke liye zaroori)

Faucet page par hCaptcha lagta hai. [hcaptcha.com](https://www.hcaptcha.com) par
free account bana kar apna domain add karein — Site Key aur Secret Key milengi.
In dono ko kahan daalna hai, neeche "Faucet — hCaptcha" section mein likha hai.

---

## STEP 2 — Google Login (OAuth) Setup

1. [console.cloud.google.com](https://console.cloud.google.com) par jayein.
2. Naya project banayein (ya existing use karein).
3. **APIs & Services → OAuth consent screen** setup karein (External, basic info bharein).
4. **APIs & Services → Credentials → Create Credentials → OAuth Client ID**
   - Application type: **Web application**
   - Authorized JavaScript origins: apni site ka domain daalein
     (jaise `https://vexora-international.com` ya testing ke liye `http://localhost:5500`)
5. **Client ID** copy kar lein.

---

## STEP 3 — Frontend Config Update Karein

`frontend/config.js` file kholein aur ye 2 lines update karein:

```js
const CONFIG = {
  API_URL: "YAHAN_APPS_SCRIPT_EXEC_URL_PASTE_KAREIN",
  GOOGLE_CLIENT_ID: "YAHAN_GOOGLE_CLIENT_ID_PASTE_KAREIN",
  ...
};
```

`frontend/index.html` mein bhi ye line dhoondh kar Client ID daal dein:
```html
data-client_id="PASTE_YOUR_GOOGLE_CLIENT_ID_HERE"
```

---

## STEP 4 — Website Host Karein

Koi bhi static hosting chalegi, jaise:
- **GitHub Pages** (free)
- **Netlify** / **Vercel** (free)
- Apna khud ka hosting/cPanel

Bas `frontend/` folder ki tamam files upload kar dein.

---

## Admin Kaam Kaise Karega (Manual Approval System)

Chunke ye Google Sheets based system hai, **admin approval manually Sheet mein hoti hai**:

- **Advertiser payment approve karna**: `Transactions` sheet mein us row ka
  `Status` column `Pending` se `Approved` kar dein.
- **Ad approve karna**: `Ads` sheet mein `Status` column `pending_review` se
  `active` kar dein — tab hi wo PTC Ads page par users ko nazar aayega.
- **Withdrawal process karna**: `Withdrawals` sheet mein `Status` ko
  `Pending` se `Approved`/`Rejected` karein aur `ProcessedAt` mein date dalein.
- **Shortlinks add karna**: `Shortlinks` sheet mein naya row add karein
  (`Status` = `active`).
- **Offerwalls add karna**: `Offerwalls` sheet mein provider ka naam +
  iframe URL + API key dalein (`Status` = `active`).

> Tip: Agar chahen to future mein ek chota "Admin Panel" page bhi bana sakte hain
> jo isi Apps Script API se connect ho — abhi ke liye Sheet hi seedha admin panel ka kaam de rahi hai.

---

## Token System

- **Currency**: Site par sab kuch **Token** mein dikhta hai (USD nahi).
- **Conversion**: `1,00,000 Token = 1 USDT`
- Ye rate `frontend/config.js` (`TOKENS_PER_USDT`) aur `backend/Code.gs`
  (`TOKENS_PER_USDT`) dono jagah set hai — dono ko sync rakhein agar change karein.

## Price Structure (PTC Ads) — Fixed Token Rewards

| Duration | User Reward (Fixed) |
|----------|----------------------|
| 5 sec    | 20 Token             |
| 10 sec   | 30 Token             |
| 30 sec   | 50 Token             |
| 60 sec   | 75 Token             |

Ye values `backend/Code.gs` mein `getRewardForDuration()` function mein
aur `frontend/earn-ptc.html` + `frontend/advertising.html` mein
`REWARD_TABLE` / `rewardTokenMap` variables mein set hain — teeno jagah
sync rakhein agar change karein.

Advertiser ki cost (jo wo asal USDT/crypto mein pay karta hai) automatically
in tokens ko USDT mein convert karke + 30% platform margin add karke
`advertising.html` mein calculate hoti hai.

---

## Faucet — hCaptcha + Random Reward

- Har **30 minute** mein 1 claim allowed hai (localStorage cooldown + backend
  Transactions log double-check karta hai).
- Har claim par **hCaptcha verify** hona zaroori hai.
- Reward har baar **random 30 se 50 Token** hota hai.

### hCaptcha Setup (zaroori)
1. [hcaptcha.com](https://www.hcaptcha.com) par free account banayein.
2. Naya "Site" add karein — apna domain daalein.
3. Aapko 2 keys milengi:
   - **Site Key** → `frontend/earn-faucet.html` mein `data-sitekey="..."` mein daalein.
   - **Secret Key** → `backend/Code.gs` mein `HCAPTCHA_SECRET_KEY` variable mein daalein
     (ye kabhi frontend mein na daalein, sirf backend mein).

---

## Withdrawal — FaucetPay → LTC

- User apna **token balance** withdraw karta hai.
- Payout **FaucetPay** ke through **LTC (Litecoin)** mein hota hai.
- Minimum withdrawal: **50,000 Token** (backend mein `MIN_WITHDRAW_TOKENS` se change kar sakte hain).
- System token amount ko USDT equivalent mein bhi save karta hai (`USDTValue` column,
  `Withdrawals` sheet mein) taake admin ko FaucetPay par LTC bhejte waqt asaani ho.
- Admin FaucetPay dashboard se manually LTC currency select karke us USDT value
  ke barabar amount user ke diye gaye FaucetPay email par bhej dega, phir
  `Withdrawals` sheet mein Status `Approved` kar dega.

### Deposit Payment Methods (Advertising ke liye)
- **FaucetPay**
- **Crypto Wallet (USDT)**

Apna FaucetPay ID aur wallet address `advertising.html` mein is line ke paas update karein:
```html
FaucetPay ID: vexora@faucetpay.io | USDT (TRC20): TXXXXXXXXXXXXXXXXXXX
```

---

## Files List

```
vexora/
├── backend/
│   └── Code.gs                 → Apps Script backend (sheets khud banata hai)
├── frontend/
│   ├── config.js                → API URL + Google Client ID yahan dalein
│   ├── style.css                → Poori site ka design
│   ├── index.html                → Login page (Google + IP tracking)
│   ├── dashboard.html            → Balance, sidebar, advertising + earn overview
│   ├── advertising.html          → Payment submit + PTC ad create karna
│   ├── earn-ptc.html             → PTC ads dekh kar kamana (timer ring)
│   ├── earn-faucet.html          → Free faucet claim
│   ├── earn-shortlinks.html      → Shortlink tasks
│   ├── earn-offerwalls.html      → Offerwall provider iframe
│   ├── withdraw.html             → Withdrawal request
│   └── transactions.html         → Poori transaction history
└── README.md                    → Ye guide
```

## Important Note

Ye system Google Sheets ko database ki tarah use karta hai jo **chote se
medium scale** ke liye theek hai (kayi sau/hazar users). Agar traffic bahut
zyada barh jaye to future mein ise Firebase ya MySQL jaisi real database par
migrate karna zaroorat par sakti hai — abhi ke liye ye setup free aur simple
hai, aur bina hang huye chalega kyunke har cheez alag sheet mein hai.
