/**************************************************************
 * VEXORA INTERNATIONAL — Backend (Google Apps Script)
 * ------------------------------------------------------------
 * Ye script Google Sheets ko backend database ki tarah use karta hai.
 * Pehli dafa run hone par khud-ba-khud alag-alag sheets bana deta hai
 * taake data mix na ho aur system slow/hang na ho.
 *
 * SHEETS (auto-created):
 *   1. Users         -> login/profile/balance/IP info
 *   2. IPLog          -> har login ki IP history (fraud check)
 *   3. Ads            -> advertiser ke submit kiye hue PTC ads
 *   4. AdClicks       -> kis user ne kaunsa ad dekha (duplicate click rokne ke liye)
 *   5. Transactions   -> deposit/spend ka pura ledger
 *   6. Withdrawals    -> withdrawal requests
 *   7. Shortlinks     -> shortlink tasks
 *   8. Offerwalls     -> offerwall provider config (manual list ya iframe link)
 *
 * SETUP:
 *  1. script.google.com par "New Project" banayein.
 *  2. Is file ka code paste karein (Code.gs).
 *  3. "Deploy" > "New deployment" > type: "Web app".
 *     - Execute as: Me
 *     - Who has access: Anyone
 *  4. Deploy karne ke baad jo URL milega, wo aapke frontend ke
 *     API_URL variable mein daalna hai (config.js file dekhein).
 *  5. Pehli request aate hi ya doPost/doGet chalne par ensureSheets()
 *     khud tamam sheets bana dega.
 **************************************************************/

const SHEET_NAMES = {
  USERS: 'Users',
  IPLOG: 'IPLog',
  ADS: 'Ads',
  CLICKS: 'AdClicks',
  TRANSACTIONS: 'Transactions',
  WITHDRAWALS: 'Withdrawals',
  SHORTLINKS: 'Shortlinks',
  OFFERWALLS: 'Offerwalls'
};

// ---------- SHEET AUTO-SETUP (isolated sheets so system never mixes/hangs) ----------
function ensureSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  const schema = {
    [SHEET_NAMES.USERS]: ['UserID','Name','Email','GoogleID','Balance','Role','Status','SignupIP','LastLoginIP','CreatedAt','LastLoginAt'],
    [SHEET_NAMES.IPLOG]: ['LogID','UserID','Email','IPAddress','Action','Timestamp'],
    [SHEET_NAMES.ADS]: ['AdID','AdvertiserEmail','Title','TargetURL','Duration','PricePerView','TotalViewsBought','ViewsUsed','Status','CreatedAt'],
    [SHEET_NAMES.CLICKS]: ['ClickID','UserID','AdID','Reward','IPAddress','Timestamp'],
    [SHEET_NAMES.TRANSACTIONS]: ['TxnID','UserID','Type','Amount','Method','Status','Reference','Timestamp'],
    [SHEET_NAMES.WITHDRAWALS]: ['WithdrawID','UserID','TokenAmount','Method','WalletAddress','Status','RequestedAt','ProcessedAt','USDTValue'],
    [SHEET_NAMES.SHORTLINKS]: ['LinkID','Title','OriginalURL','ShortURL','Reward','Status'],
    [SHEET_NAMES.OFFERWALLS]: ['WallID','ProviderName','IframeURL','APIKey','Status']
  };

  Object.keys(schema).forEach(name => {
    let sheet = ss.getSheetByName(name);
    if (!sheet) {
      sheet = ss.insertSheet(name);
      sheet.appendRow(schema[name]);
      sheet.setFrozenRows(1);
      sheet.getRange(1, 1, 1, schema[name].length).setFontWeight('bold').setBackground('#0F1229').setFontColor('#F5B942');
    }
  });

  // remove default "Sheet1" if empty and unused
  const def = ss.getSheetByName('Sheet1');
  if (def && def.getLastRow() === 0 && ss.getSheets().length > 1) {
    ss.deleteSheet(def);
  }
}

// ---------- HELPERS ----------
function getSheet(name) {
  ensureSheets();
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
}

function sheetToObjects(sheet) {
  const data = sheet.getDataRange().getValues();
  const headers = data.shift();
  return data.map(row => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);
    return obj;
  });
}

function findRowIndexByValue(sheet, columnName, value) {
  const data = sheet.getDataRange().getValues();
  const headers = data[0];
  const col = headers.indexOf(columnName);
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][col]) === String(value)) return i + 1; // 1-indexed row
  }
  return -1;
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function generateId(prefix) {
  return prefix + '_' + Utilities.getUuid().split('-')[0] + Date.now();
}

// ---------- ENTRY POINTS ----------
function doGet(e) {
  ensureSheets();
  const action = e.parameter.action;

  try {
    if (action === 'getUser') return jsonResponse(getUser(e.parameter.email));
    if (action === 'getAds') return jsonResponse(getActiveAds());
    if (action === 'getShortlinks') return jsonResponse(getActiveShortlinks());
    if (action === 'getOfferwalls') return jsonResponse(getActiveOfferwalls());
    if (action === 'getTransactions') return jsonResponse(getUserTransactions(e.parameter.userId));
    if (action === 'getWithdrawals') return jsonResponse(getUserWithdrawals(e.parameter.userId));
    return jsonResponse({ error: 'Unknown GET action' });
  } catch (err) {
    return jsonResponse({ error: err.message });
  }
}

function doPost(e) {
  ensureSheets();
  const body = JSON.parse(e.postData.contents);
  const action = body.action;
  const ip = body.ip || 'unknown';

  try {
    if (action === 'loginWithGoogle') return jsonResponse(loginOrCreateUser(body, ip));
    if (action === 'submitAd') return jsonResponse(submitAd(body));
    if (action === 'watchAd') return jsonResponse(recordAdView(body, ip));
    if (action === 'requestWithdraw') return jsonResponse(requestWithdraw(body));
    if (action === 'depositFunds') return jsonResponse(depositFunds(body));
    if (action === 'completeShortlink') return jsonResponse(completeShortlink(body, ip));
    if (action === 'completeOfferwall') return jsonResponse(completeOfferwall(body, ip));
    if (action === 'claimFaucet') return jsonResponse(claimFaucet(body, ip));
    return jsonResponse({ error: 'Unknown POST action' });
  } catch (err) {
    return jsonResponse({ error: err.message });
  }
}

// ---------- USERS / LOGIN (Google login handled on frontend via Google Identity;
// backend just records/creates the user profile + IP log) ----------
function loginOrCreateUser(body, ip) {
  const sheet = getSheet(SHEET_NAMES.USERS);
  const users = sheetToObjects(sheet);
  let user = users.find(u => u.Email === body.email);
  const now = new Date();

  if (!user) {
    const userId = generateId('U');
    sheet.appendRow([userId, body.name, body.email, body.googleId, 0, 'user', 'active', ip, ip, now, now]);
    user = { UserID: userId, Name: body.name, Email: body.email, Balance: 0, Role: 'user', Status: 'active' };
    logIP(userId, body.email, ip, 'signup');
  } else {
    const rowIdx = findRowIndexByValue(sheet, 'Email', body.email);
    sheet.getRange(rowIdx, 9).setValue(ip);   // LastLoginIP
    sheet.getRange(rowIdx, 11).setValue(now); // LastLoginAt
    logIP(user.UserID, body.email, ip, 'login');
  }
  return { success: true, user: user };
}

function getUser(email) {
  const sheet = getSheet(SHEET_NAMES.USERS);
  const users = sheetToObjects(sheet);
  const user = users.find(u => u.Email === email);
  return user ? { success: true, user: user } : { success: false, error: 'User not found' };
}

function logIP(userId, email, ip, action) {
  const sheet = getSheet(SHEET_NAMES.IPLOG);
  sheet.appendRow([generateId('LOG'), userId, email, ip, action, new Date()]);
}

// ---------- ADS (Advertising Board) ----------
// Advertiser pehle payment bhejta hai (FaucetPay/Crypto) -> admin manually
// "Transactions" sheet mein Status = Approved karta hai -> tab wo ad submit kar sakta hai.
function submitAd(body) {
  // check advertiser has an approved deposit transaction covering cost
  const txnSheet = getSheet(SHEET_NAMES.TRANSACTIONS);
  const txns = sheetToObjects(txnSheet);
  const approved = txns.find(t => t.UserID === body.userId && t.Type === 'deposit' && t.Status === 'Approved' && !t.usedForAd);
  if (!approved) {
    return { success: false, error: 'Koi approved payment nahi mila. Pehle payment bhejein aur admin approval ka intezaar karein.' };
  }

  const sheet = getSheet(SHEET_NAMES.ADS);
  const adId = generateId('AD');
  sheet.appendRow([adId, body.email, body.title, body.targetUrl, body.duration, body.pricePerView, body.totalViews, 0, 'pending_review', new Date()]);
  return { success: true, message: 'Ad submit ho gaya, admin review ke baad live hoga.', adId: adId };
}

function getActiveAds() {
  const sheet = getSheet(SHEET_NAMES.ADS);
  const ads = sheetToObjects(sheet).filter(a => a.Status === 'active' && Number(a.ViewsUsed) < Number(a.TotalViewsBought));
  return { success: true, ads: ads };
}

function recordAdView(body, ip) {
  const clickSheet = getSheet(SHEET_NAMES.CLICKS);
  const clicks = sheetToObjects(clickSheet);
  const already = clicks.find(c => c.UserID === body.userId && c.AdID === body.adId &&
    new Date(c.Timestamp).toDateString() === new Date().toDateString());
  if (already) return { success: false, error: 'Ye ad aap aaj dekh chuke hain.' };

  const adSheet = getSheet(SHEET_NAMES.ADS);
  const adRow = findRowIndexByValue(adSheet, 'AdID', body.adId);
  if (adRow === -1) return { success: false, error: 'Ad not found' };

  const ads = sheetToObjects(adSheet);
  const ad = ads[adRow - 2];
  const reward = getRewardForDuration(ad.Duration); // fixed token reward by duration

  clickSheet.appendRow([generateId('CLK'), body.userId, body.adId, reward, ip, new Date()]);
  adSheet.getRange(adRow, 8).setValue(Number(ad.ViewsUsed) + 1); // ViewsUsed

  creditBalance(body.userId, reward, 'ptc_earning', 'Ad:' + body.adId);
  return { success: true, reward: reward };
}

// ---------- PTC REWARD TABLE (fixed tokens per duration) ----------
function getRewardForDuration(duration) {
  const table = { '5': 20, '10': 30, '30': 50, '60': 75 };
  return table[String(duration)] || 0;
}

// ---------- BALANCE / TRANSACTIONS ----------
function creditBalance(userId, amount, type, reference) {
  const userSheet = getSheet(SHEET_NAMES.USERS);
  const rowIdx = findRowIndexByValue(userSheet, 'UserID', userId);
  if (rowIdx === -1) return;
  const currentBalance = Number(userSheet.getRange(rowIdx, 5).getValue());
  userSheet.getRange(rowIdx, 5).setValue(currentBalance + amount);

  const txnSheet = getSheet(SHEET_NAMES.TRANSACTIONS);
  txnSheet.appendRow([generateId('TXN'), userId, type, amount, 'internal', 'Approved', reference, new Date()]);
}

function depositFunds(body) {
  // User FaucetPay/Crypto se payment bhejta hai; ye sirf request record karta hai.
  // Admin Transactions sheet mein "Status" ko "Approved" manually set karega.
  const sheet = getSheet(SHEET_NAMES.TRANSACTIONS);
  const txnId = generateId('TXN');
  sheet.appendRow([txnId, body.userId, 'deposit', body.amount, body.method, 'Pending', body.reference || '', new Date()]);
  return { success: true, message: 'Payment record ho gaya. Approval ke baad ads submit kar sakte hain.', txnId: txnId };
}

function getUserTransactions(userId) {
  const sheet = getSheet(SHEET_NAMES.TRANSACTIONS);
  const txns = sheetToObjects(sheet).filter(t => t.UserID === userId);
  return { success: true, transactions: txns };
}

// ---------- WITHDRAWALS ----------
const TOKENS_PER_USDT = 100000; // 1,00,000 token = 1 USDT
const MIN_WITHDRAW_TOKENS = 50000; // example minimum: 50,000 token (~0.5 USDT)

function requestWithdraw(body) {
  const tokenAmount = Number(body.amount);
  if (tokenAmount < MIN_WITHDRAW_TOKENS) {
    return { success: false, error: 'Minimum withdrawal ' + MIN_WITHDRAW_TOKENS.toLocaleString() + ' token hai.' };
  }

  const userSheet = getSheet(SHEET_NAMES.USERS);
  const rowIdx = findRowIndexByValue(userSheet, 'UserID', body.userId);
  if (rowIdx === -1) return { success: false, error: 'User not found' };
  const balance = Number(userSheet.getRange(rowIdx, 5).getValue());
  if (balance < tokenAmount) return { success: false, error: 'Balance kam hai.' };

  userSheet.getRange(rowIdx, 5).setValue(balance - tokenAmount);

  // FaucetPay LTC payout ke liye USDT equivalent nikalna (FaucetPay khud USDT -> LTC convert kar deta hai
  // agar aap LTC currency select karke bhejte hain; ye value sirf admin reference ke liye record hoti hai)
  const usdtValue = tokenAmount / TOKENS_PER_USDT;

  const sheet = getSheet(SHEET_NAMES.WITHDRAWALS);
  const wId = generateId('WD');
  sheet.appendRow([wId, body.userId, tokenAmount, 'FaucetPay (LTC)', body.walletAddress, 'Pending', new Date(), '', usdtValue]);
  return { success: true, message: 'Withdrawal request bhej di gayi hai. LTC mein FaucetPay ke zariye process hogi.', withdrawId: wId, usdtValue: usdtValue };
}

function getUserWithdrawals(userId) {
  const sheet = getSheet(SHEET_NAMES.WITHDRAWALS);
  const rows = sheetToObjects(sheet).filter(w => w.UserID === userId);
  return { success: true, withdrawals: rows };
}

// ---------- FAUCET (hCaptcha verified, 30-min cooldown, random 30-50 token) ----------
// NOTE: Server-side hCaptcha verify ke liye apna hCaptcha "Secret Key"
// (site key nahi) yahan neeche daalein. Ye secret key kabhi bhi frontend
// code mein na daalein — sirf yahan backend mein rahe.
const HCAPTCHA_SECRET_KEY = 'PASTE_YOUR_HCAPTCHA_SECRET_KEY_HERE';

function verifyHCaptcha(token) {
  if (!token) return false;
  try {
    const res = UrlFetchApp.fetch('https://hcaptcha.com/siteverify', {
      method: 'post',
      payload: { secret: HCAPTCHA_SECRET_KEY, response: token },
      muteHttpExceptions: true
    });
    const data = JSON.parse(res.getContentText());
    return data.success === true;
  } catch (e) {
    return false;
  }
}

function claimFaucet(body, ip) {
  // 1) hCaptcha check
  const captchaOk = verifyHCaptcha(body.captchaToken);
  if (!captchaOk) {
    return { success: false, error: 'Captcha verify nahi ho saka. Dobara koshish karein.' };
  }

  // 2) 30-minute cooldown check via Transactions log
  const txnSheet = getSheet(SHEET_NAMES.TRANSACTIONS);
  const txns = sheetToObjects(txnSheet).filter(t => t.UserID === body.userId && t.Type === 'faucet_earning');
  if (txns.length) {
    const last = txns.sort((a, b) => new Date(b.Timestamp) - new Date(a.Timestamp))[0];
    const diffMs = Date.now() - new Date(last.Timestamp).getTime();
    const cooldownMs = 30 * 60 * 1000;
    if (diffMs < cooldownMs) {
      const remainingMin = Math.ceil((cooldownMs - diffMs) / 60000);
      return { success: false, error: 'Agla claim ' + remainingMin + ' minute baad available hoga.' };
    }
  }

  // 3) random reward 30-50 tokens
  const reward = Math.floor(Math.random() * (50 - 30 + 1)) + 30;
  creditBalance(body.userId, reward, 'faucet_earning', 'Faucet claim IP:' + ip);
  return { success: true, reward: reward };
}

// ---------- SHORTLINKS ----------
function getActiveShortlinks() {
  const sheet = getSheet(SHEET_NAMES.SHORTLINKS);
  const rows = sheetToObjects(sheet).filter(s => s.Status === 'active');
  return { success: true, shortlinks: rows };
}

function completeShortlink(body, ip) {
  const sheet = getSheet(SHEET_NAMES.SHORTLINKS);
  const rows = sheetToObjects(sheet);
  const link = rows.find(l => l.LinkID === body.linkId);
  if (!link) return { success: false, error: 'Link not found' };
  creditBalance(body.userId, Number(link.Reward), 'shortlink_earning', 'Link:' + body.linkId);
  return { success: true, reward: Number(link.Reward) };
}

// ---------- OFFERWALLS ----------
function getActiveOfferwalls() {
  const sheet = getSheet(SHEET_NAMES.OFFERWALLS);
  const rows = sheetToObjects(sheet).filter(o => o.Status === 'active');
  return { success: true, offerwalls: rows };
}

function completeOfferwall(body, ip) {
  // Real offerwall providers postback yahan hit karenge (server-to-server).
  // Manual/demo ke liye: reward seedha credit.
  creditBalance(body.userId, Number(body.reward || 0), 'offerwall_earning', 'Wall:' + body.wallId);
  return { success: true };
}
